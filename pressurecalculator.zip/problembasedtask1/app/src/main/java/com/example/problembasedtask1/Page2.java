package com.example.problembasedtask1;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class Page2 extends AppCompatActivity {

    //define object
    EditText txt1;
    RadioButton newton;
    RadioButton kilonewton;
    RadioButton Force;
    RadioButton Pound;
    TextView result;
    EditText txt2;
    RadioButton pascal;
    RadioButton kilopascal;
    RadioButton bar;
    RadioButton psi;
    TextView result2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        txt1 = (EditText) findViewById(R.id.Text1);
        newton = (RadioButton) findViewById(R.id.RbtnNewtoon);
        kilonewton = (RadioButton) findViewById(R.id.Rbtnkilo);
        Force = (RadioButton) findViewById(R.id.rbtnkilogram);
        Pound = (RadioButton) findViewById(R.id.rbtnNewtoon);
        result = (TextView) findViewById(R.id.Txttotal1);
        txt2= (EditText) findViewById(R.id.Text2);
        pascal = (RadioButton) findViewById(R.id.rbtnPascal);
        kilopascal = (RadioButton) findViewById(R.id.rbtnKilo);
        bar = (RadioButton) findViewById(R.id.rbtnBar);
        psi = (RadioButton) findViewById(R.id.rbtnPsi);
        result2 = (TextView) findViewById(R.id.txtTotal2);




        newton.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number1 = Double.parseDouble(txt1.getText().toString());

                //formula newton to kilonewton
                double Newton = number1 / 1000;


                result.setText(Double.toString(Newton));
            }
        });


        kilonewton.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number1 = Double.parseDouble(txt1.getText().toString());

                //formula kilonewton to newton
                double kg = number1 * 1000;

                //result to kg
                result.setText(Double.toString(kg));
            }
        });


        Force.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number1 = Double.parseDouble(txt1.getText().toString());

                //formula kilogram-force to newton
                double kgF = number1 * 9.80665;

                //result to Force
                result.setText(Double.toString(kgF));
            }
        });

        Pound.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number1 = Double.parseDouble(txt1.getText().toString());

                //formula newton to pound-force
                double NPF = number1 / 4.44822162;

                //result to Pound
                result.setText(Double.toString(NPF));
            }
        });


        pascal.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number2 = Double.parseDouble(txt2.getText().toString());

                //formula pascal to kilo pascal
                double pascal= number2 / 1000;

                //result to pascal
                result2.setText(Double.toString(pascal));
            }
        });


        kilopascal.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number2 = Double.parseDouble(txt2.getText().toString());

                //formula kilo to pascal
                double kilo = number2 * 1000;

                //result to kilo
                result2.setText(Double.toString(kilo));
            }
        });


        bar.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number2 = Double.parseDouble(txt2.getText().toString());

                //formula bar to psi
                double B = number2 * 14.5037738;

                //result to bar
                result2.setText(Double.toString(B));
            }
        });



        psi.setOnClickListener(new View.OnClickListener() {

            public void onClick (View v) {

                double number2 = Double.parseDouble(txt2.getText().toString());

                //formula psi to bar
                double p = number2 / 14.5037738;

                //result to psi
                result2.setText(Double.toString(p));
            }
        });

    }

    public void txtViewTitle (View view){
        Intent i2 = new Intent(Page2.this, MainActivity.class);
        Page2.this.startActivity(i2);
    }
}